// StepUp • Student account email upgrade
// Adds an email + password to the SAME Firebase user (same UID) after legacy name + PIN login.
// Existing progress remains linked to the unchanged Firebase UID.
(function(){
  "use strict";

  if(!window.PROVE || !window.firebase || !firebase.auth || !firebase.firestore) return;

  var originalContinue = window.PROVE.studentContinue;
  var originalRegister = window.PROVE.studentRegister;
  var LEGACY_DOMAIN = "@students.proveit.local";
  var observerTimer = null;
  var upgradeBusy = false;
  var activeVerifiedUpgrade = null;

  function auth(){ return firebase.auth(); }
  function db(){ return firebase.firestore(); }

  function esc(value){
    return String(value == null ? "" : value).replace(/[&<>"']/g,function(ch){
      return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[ch];
    });
  }

  function classCodeFromUrl(){
    var code = new URLSearchParams(window.location.search).get("class");
    return code ? code.trim().toUpperCase() : "";
  }

  async function sha256(text){
    var bytes = new TextEncoder().encode(text);
    var hash = await crypto.subtle.digest("SHA-256", bytes);
    return Array.from(new Uint8Array(hash)).map(function(b){
      return b.toString(16).padStart(2,"0");
    }).join("");
  }

  async function legacyCreds(name,classCode,pin){
    var normalized = classCode.toUpperCase().trim() + "|" + name.toLowerCase().trim().replace(/\s+/g," ");
    var h = await sha256(normalized);
    return {
      email: "s_" + h.slice(0,24) + LEGACY_DOMAIN,
      password: String(pin) + "Aa!" + h.slice(0,4)
    };
  }

  function isLegacyEmail(email){
    return String(email || "").toLowerCase().endsWith(LEGACY_DOMAIN);
  }

  function legacyId(email){
    return String(email || "").toLowerCase().split("@")[0];
  }

  function skipKey(uid){
    return "stepup_skip_email_upgrade_" + String(uid || "");
  }

  function upgradedKey(email){
    return "stepup_account_upgraded_" + legacyId(email);
  }

  function pendingUidKey(uid){
    return "stepup_pending_email_upgrade_uid_" + String(uid || "");
  }

  function pendingLegacyKey(email){
    return "stepup_pending_email_upgrade_legacy_" + legacyId(email);
  }

  function savePendingUpgrade(data){
    if(!data || !data.uid || !data.legacyEmail) return;
    var raw = JSON.stringify(data);
    localStorage.setItem(pendingUidKey(data.uid),raw);
    localStorage.setItem(pendingLegacyKey(data.legacyEmail),raw);
  }

  function readPendingByUid(uid){
    try{return JSON.parse(localStorage.getItem(pendingUidKey(uid)) || "null");}catch(e){return null;}
  }

  function readPendingByLegacy(email){
    try{return JSON.parse(localStorage.getItem(pendingLegacyKey(email)) || "null");}catch(e){return null;}
  }

  function clearPendingUpgrade(data){
    if(!data) return;
    if(activeVerifiedUpgrade?.uid===data.uid)activeVerifiedUpgrade=null;
    if(data.uid) localStorage.removeItem(pendingUidKey(data.uid));
    if(data.legacyEmail) localStorage.removeItem(pendingLegacyKey(data.legacyEmail));
  }

  function findAnyPendingUpgrade(){
    try{
      var found = null;
      Object.keys(localStorage).some(function(k){
        if(k.indexOf("stepup_pending_email_upgrade_uid_") !== 0) return false;
        var x = JSON.parse(localStorage.getItem(k) || "null");
        if(x && x.uid && x.legacyEmail && x.newEmail){
          found = x;
          return true;
        }
        return false;
      });
      return found;
    }catch(e){
      return null;
    }
  }

  function legacyPasswordFromCurrentEmail(email,pin){
    var id = legacyId(email);
    var h4 = id.indexOf("s_") === 0 ? id.slice(2,6) : "";
    return String(pin) + "Aa!" + h4;
  }

  function friendlyError(error,context){
    var code = error && error.code ? error.code : "";
    if(code === "auth/email-already-in-use") return "هذا البريد الإلكتروني مرتبط بحساب آخر.";
    if(code === "auth/invalid-email") return "تحققي من كتابة البريد الإلكتروني.";
    if(code === "auth/weak-password") return "اختاري كلمة مرور أقوى.";
    if(code === "auth/wrong-password" || code === "auth/invalid-credential") {
      return context === "upgrade" ? "رمز PIN الحالي غير صحيح." : "بيانات الدخول غير صحيحة.";
    }
    if(code === "auth/user-not-found") return "لم يتم العثور على الحساب.";
    if(code === "auth/too-many-requests") return "تمت محاولات كثيرة. حاولي مرة أخرى لاحقًا.";
    if(code === "auth/network-request-failed") return "تعذر الاتصال بالإنترنت. تحققي من الشبكة وحاولي مرة أخرى.";
    if(code === "auth/requires-recent-login") return "أعيدي تسجيل الدخول ثم حاولي تحديث الحساب مرة أخرى.";
    if(code === "auth/user-token-expired") return "انتهت جلسة الدخول القديمة بعد تأكيد البريد. سنعيد ربط الجلسة بالحساب نفسه.";
    if(code === "auth/operation-not-allowed") return "يتطلب Firebase التحقق من البريد الجديد أولًا. أُعيد ترتيب الخطوات لهذا الغرض.";
    return (error && error.message) ? error.message : "تعذر إكمال العملية.";
  }

  async function getClassByCode(code){
    var snap = await db().collection("joinCodes").doc(code).get();
    if(!snap.exists) return null;
    var j = snap.data() || {};
    return {
      id:j.classId,
      code:code,
      name:j.className || "",
      teacherId:j.teacherId,
      school:j.school || ""
    };
  }

  // The teacher is the recovery path: keep each student's PIN on her own profile
  // (readable only by her and her teacher under the Firestore rules).
  async function savePin(uid,pin,attempt){
    if(!uid || !/^\d{4}$/.test(String(pin||""))) return;
    try{
      var ref = db().collection("users").doc(uid);
      var snap = await ref.get();
      if(!snap.exists){
        if((attempt||0) < 3) setTimeout(function(){ savePin(uid,pin,(attempt||0)+1); },1500);
        return;
      }
      if((snap.data() || {}).role !== "student") return true;
      if((snap.data() || {}).pin === String(pin)) return true;
      await ref.update({pin:String(pin)});
      return true;
    }catch(error){
      console.warn("StepUp PIN save skipped",error && (error.code || error.message));
      return false;
    }
  }

  async function ensureStudentProfile(user,name,classObj,classCode){
    var ref = db().collection("users").doc(user.uid);
    var snap = await ref.get();
    if(snap.exists) return;
    await ref.set({
      role:"student",
      displayName:name,
      classId:classObj.id,
      classCode:classCode,
      teacherId:classObj.teacherId,
      school:classObj.school || "",
      createdAt:new Date().toISOString()
    });
  }

  async function studentContinue(forcedClassCode){
    if(!firebase.apps || !firebase.apps.length){
      return originalContinue ? originalContinue.apply(window.PROVE,arguments) : null;
    }

    var nameEl = document.getElementById("stName");
    var codeEl = document.getElementById("stClassCode");
    var pinEl = document.getElementById("stPin");
    var name = nameEl ? nameEl.value.trim() : "";
    var classCode = String(forcedClassCode || (codeEl ? codeEl.value : "") || "").trim().toUpperCase();
    var pin = pinEl ? pinEl.value.trim() : "";

    if(!name || !classCode || !/^\d{4}$/.test(pin)){
      alert("أدخلي الاسم الكامل وPIN المكوّن من 4 أرقام.");
      return;
    }

    var classObj = await getClassByCode(classCode);
    if(!classObj){
      alert("تعذر العثور على الفصل. تحققي من الرابط أو كود الفصل.");
      return;
    }

    var creds = await legacyCreds(name,classCode,pin);

    try{
      var result = await auth().signInWithEmailAndPassword(creds.email,creds.password);
      await ensureStudentProfile(result.user,name,classObj,classCode);
      savePin(result.user.uid,pin);
    }catch(error){
      var pending = readPendingByLegacy(creds.email);
      if(pending && pending.newEmail){
        try{
          var pendingResult = await auth().signInWithEmailAndPassword(pending.newEmail,creds.password);
          await ensureStudentProfile(pendingResult.user,name,classObj,classCode);
          savePin(pendingResult.user.uid,pin);
          setTimeout(maybeShowUpgrade,180);
          return;
        }catch(pendingError){
          console.warn("StepUp pending upgraded-email login failed",pendingError);
        }
      }
      console.warn("StepUp legacy student login failed",error);
      alert(
        "لم نتمكن من الدخول بهذه البيانات.\n\n" +
        "• اكتبي اسمك بالطريقة نفسها التي سجّلتِ بها أول مرة.\n" +
        "• تأكدي من رمز PIN (4 أرقام).\n\n" +
        "إذا نسيتِ رمز PIN، تواصلي مع معلمتك وستزوّدك به.\n\n" +
        "إذا سبق أن ربطتِ بريدك واخترتِ كلمة مرور، اختاري «الدخول بالبريد الإلكتروني»."
      );
    }
  }

  async function studentRegister(forcedClassCode){
    if(!originalRegister) return;

    var nameEl = document.getElementById("stName");
    var codeEl = document.getElementById("stClassCode");
    var pinEl = document.getElementById("stPin");
    var name = nameEl ? nameEl.value.trim() : "";
    var classCode = String(forcedClassCode || (codeEl ? codeEl.value : "") || "").trim().toUpperCase();
    var pin = pinEl ? pinEl.value.trim() : "";

    if(!name || !classCode || !/^\d{4}$/.test(pin)){
      alert("لإنشاء الحساب أدخلي الاسم الكامل وPIN المكوّن من 4 أرقام.");
      return;
    }

    rememberPin();
    var creds = await legacyCreds(name,classCode,pin);
    if(localStorage.getItem(upgradedKey(creds.email)) === "1"){
      alert("سبق ربط هذا الحساب ببريد إلكتروني. اختاري «الدخول بالبريد الإلكتروني» للدخول إلى حسابك نفسه. ربط البريد اختياري للحسابات الأخرى.");
      return;
    }

    var ok = confirm(
      "إنشاء حساب جديد — لأول استخدام فقط.\n\n" +
      "إذا سبق لك استخدام Step Up من قبل، اختاري «إلغاء» ثم استخدمي «دخول بالحساب الحالي» حتى يبقى تقدمك محفوظًا في حسابك نفسه.\n\n" +
      "هل هذه أول مرة لك فعلًا في Step Up؟"
    );
    if(!ok) return;

    var temporaryCode = null;
    if(!codeEl){
      temporaryCode = document.createElement("input");
      temporaryCode.type = "hidden";
      temporaryCode.id = "stClassCode";
      temporaryCode.value = classCode;
      (nameEl && nameEl.parentNode ? nameEl.parentNode : document.body).appendChild(temporaryCode);
    }else if(forcedClassCode){
      codeEl.value = classCode;
    }

    try{
      var registered = await originalRegister.call(window.PROVE);
      if(auth().currentUser) savePin(auth().currentUser.uid,pin);
      return registered;
    }finally{
      if(temporaryCode) temporaryCode.remove();
    }
  }

  async function studentEmailLogin(){
    var emailEl = document.getElementById("stepupStudentEmail");
    var passwordEl = document.getElementById("stepupStudentPassword");
    var email = emailEl ? emailEl.value.trim().toLowerCase() : "";
    var password = passwordEl ? passwordEl.value : "";

    if(!email || !password){
      alert("أدخلي البريد الإلكتروني وكلمة المرور.");
      return;
    }

    try{
      var result = await auth().signInWithEmailAndPassword(email,password);
      var snap = await db().collection("users").doc(result.user.uid).get();
      var profile = snap.exists ? snap.data() : null;
      if(!profile || profile.role !== "student"){
        await auth().signOut();
        alert("هذا الحساب ليس حساب طالبة في Step Up.");
        return;
      }

      var pending = findAnyPendingUpgrade();
      if(pending &&
         pending.uid === result.user.uid &&
         String(pending.newEmail || "").toLowerCase() === email){
        localStorage.setItem(upgradedKey(pending.legacyEmail),"1");
        sessionStorage.removeItem(skipKey(result.user.uid));
        clearPendingUpgrade(pending);
      }
    }catch(error){
      alert("تعذر تسجيل الدخول: " + friendlyError(error,"emailLogin"));
    }
  }

  async function studentResetPassword(){
    var emailEl = document.getElementById("stepupStudentEmail");
    var email = emailEl ? emailEl.value.trim().toLowerCase() : "";
    if(!email){
      email = (prompt("اكتبي البريد الإلكتروني المرتبط بحسابك:") || "").trim().toLowerCase();
    }
    if(!email) return;

    try{
      auth().languageCode = "ar";
      await auth().sendPasswordResetEmail(email);
      alert("تم طلب رابط استعادة كلمة المرور. تحققي من البريد والرسائل غير المرغوبة؛ قد يتأخر وصوله.");
    }catch(error){
      alert("تعذر إرسال رابط الاستعادة: " + friendlyError(error,"reset"));
    }
  }

  function emailLoginHTML(){
    var classCode = classCodeFromUrl();
    var classLine = classCode ? '<div class="stepup-account-class">رابط الفصل محفوظ — سجلي ببريدك فقط</div>' : "";
    return [
      '<div class="auth-shell stepup-email-login-page" dir="rtl">',
        '<div class="card stepup-email-login-card">',
          '<div class="stepup-account-brand">STEP <span>UP</span></div>',
          '<div class="eyebrow">تسجيل دخول الطالبة</div>',
          '<h1>الدخول بالبريد الإلكتروني</h1>',
          '<p class="muted"><strong>سبق أن ربطتِ بريدك؟</strong><br>اكتبي بريدك وكلمة المرور التي اخترتِها. إذا لم تربطي بريدًا من قبل، عودي للدخول بالاسم وPIN.</p>',
          classLine,
          '<div class="stepup-account-form">',
            '<label for="stepupStudentEmail">البريد الإلكتروني</label>',
            '<input id="stepupStudentEmail" type="email" inputmode="email" autocomplete="username" placeholder="name@example.com">',
            '<label for="stepupStudentPassword">كلمة المرور</label>',
            '<input id="stepupStudentPassword" type="password" autocomplete="current-password" placeholder="••••••••">',
          '</div>',
          '<button class="btn btn-primary stepup-account-main-btn" id="stepupStudentEmailLoginBtn">دخول</button>',
          '<div class="stepup-account-link-row">',
            '<button class="stepup-account-link" id="stepupResetPasswordBtn">نسيت كلمة المرور؟</button>',
            '<button class="stepup-account-link" id="stepupBackLegacyBtn">العودة للدخول بالاسم وPIN</button>',
          '</div>',
          '<div class="stepup-account-safe-note">نفس حسابك ونفس تقدمك — فقط طريقة دخول أكثر أمانًا.</div>',
        '</div>',
      '</div>'
    ].join("");
  }

  function showEmailLogin(){
    var app = document.getElementById("app");
    if(!app) return;
    app.innerHTML = emailLoginHTML();
    var loginBtn = document.getElementById("stepupStudentEmailLoginBtn");
    var resetBtn = document.getElementById("stepupResetPasswordBtn");
    var backBtn = document.getElementById("stepupBackLegacyBtn");
    if(loginBtn) loginBtn.addEventListener("click",studentEmailLogin);
    if(resetBtn) resetBtn.addEventListener("click",studentResetPassword);
    if(backBtn) backBtn.addEventListener("click",function(){ window.location.reload(); });
    var pass = document.getElementById("stepupStudentPassword");
    if(pass) pass.addEventListener("keydown",function(e){
      if(e.key === "Enter") studentEmailLogin();
    });
  }

  function skipUpgrade(){
    var user = auth().currentUser;
    if(user) sessionStorage.setItem(skipKey(user.uid),"1");
    var overlay = document.getElementById("stepupAccountUpgradeOverlay");
    if(overlay) overlay.remove();
  }

  function upgradeHTML(profile){
    var firstName = esc(((profile && profile.displayName) || "طالبة").trim().split(/\s+/)[0]);
    return [
      '<div id="stepupAccountUpgradeOverlay" class="stepup-account-overlay" dir="rtl" role="dialog" aria-modal="true" aria-labelledby="stepupUpgradeTitle">',
        '<div class="stepup-account-upgrade-card">',
          '<div class="stepup-account-update-badge">اختياري</div>',
          '<h2 id="stepupUpgradeTitle">احفظي طريقة استعادة حسابك</h2>',
          '<p class="stepup-account-lead">إذا كنتِ تخافين تنسين PIN، أضيفي بريدك الإلكتروني. وإذا ما تحتاجين، تخطي وكَمّلي عادي.</p>',
          '<div class="stepup-account-preserve">',
            '<span class="stepup-account-check">✓</span>',
            '<div><strong>لن يتغير حسابك أو تقدمك</strong><small>البريد فقط يعطيك طريقة لاستعادة الدخول إذا نسيتِ بياناتك.</small></div>',
          '</div>',
          '<div class="stepup-account-form">',
            '<label for="stepupUpgradeEmail">بريدك الإلكتروني</label>',
            '<input id="stepupUpgradeEmail" type="email" inputmode="email" autocomplete="email" placeholder="name@example.com">',
            '<label for="stepupUpgradeEmailConfirm">أعيدي كتابة البريد للتأكد</label>',
            '<input id="stepupUpgradeEmailConfirm" type="email" inputmode="email" autocomplete="email" placeholder="name@example.com">',
            '<label for="stepupUpgradePin">PIN الحالي</label>',
            '<input id="stepupUpgradePin" type="password" inputmode="numeric" maxlength="4" autocomplete="current-password" placeholder="4 أرقام">',
          '</div>',
          '<button id="stepupCompleteUpgradeBtn" class="btn btn-primary stepup-account-main-btn">أضيفي بريدي للاستعادة</button>',
          '<button id="stepupSkipUpgradeBtn" class="stepup-account-skip">لا أحتاجه الآن — متابعة</button>',
          '<div class="stepup-account-footer-note">سنرسل رسالة واحدة لتأكيد البريد. بعد التأكيد تختارين كلمة المرور هنا مباشرة دون رسالة ثانية.</div>',
        '</div>',
      '</div>'
    ].join("");
  }

  function verificationHTML(profile,pending){
    var firstName = esc(((profile && profile.displayName) || "طالبة").trim().split(/\s+/)[0]);
    return [
      '<div id="stepupAccountUpgradeOverlay" class="stepup-account-overlay" dir="rtl" role="dialog" aria-modal="true">',
        '<div class="stepup-account-upgrade-card">',
          '<div class="stepup-account-update-badge">1 من 2</div>',
          '<h2>أكدي بريدك يا ' + firstName + '</h2>',
          '<p class="stepup-account-lead">أرسلنا رسالة إلى:</p>',
          '<div class="stepup-account-email-chip">' + esc(pending.newEmail) + '</div>',
          '<div class="stepup-account-preserve">',
            '<span class="stepup-account-check">✉</span>',
            '<div><strong>افتحي الرسالة واضغطي رابط التأكيد</strong><small>بعدها ارجعي هنا واضغطي الزر أدناه.</small></div>',
          '</div>',
          '<button id="stepupCheckVerificationBtn" class="btn btn-primary stepup-account-main-btn">أكدت بريدي — متابعة</button>',
          '<button id="stepupResendVerificationBtn" class="stepup-account-skip">ما وصلتني الرسالة — إعادة الإرسال</button>',
          '<button id="stepupRestartUpgradeBtn" class="stepup-account-skip">كتبت بريدًا خطأ — تغييره</button>',
          '<div class="stepup-account-footer-note">إذا لم تجدي الرسالة، تحققي من Junk / Spam.</div>',
        '</div>',
      '</div>'
    ].join("");
  }

  function passwordSetupKey(pending){
    return "stepup_password_setup_sent_" + String((pending && pending.uid) || "");
  }

  function recoveryHTML(pending){
    return [
      '<div id="stepupAccountUpgradeOverlay" class="stepup-account-overlay" dir="rtl" role="dialog" aria-modal="true">',
        '<div class="stepup-account-upgrade-card">',
          '<div class="stepup-account-update-badge">2 من 2</div>',
          '<h2>تم تأكيد بريدك ✓</h2>',
          '<p class="stepup-account-lead">أرسلنا لك الآن رسالة ثانية لاختيار كلمة مرور لحسابك.</p>',
          '<div class="stepup-account-email-chip">' + esc(pending.newEmail) + '</div>',
          '<div class="stepup-account-preserve">',
            '<span class="stepup-account-check">✓</span>',
            '<div><strong>افتحي الرسالة واختاري كلمة مرور</strong><small>ثم ارجعي إلى Step Up وسجلي بالبريد وكلمة المرور التي اخترتِها.</small></div>',
          '</div>',
          '<button id="stepupGoEmailLoginBtn" class="btn btn-primary stepup-account-main-btn">اخترت كلمة المرور — الدخول بالبريد</button>',
          '<button id="stepupRecoverSessionBtn" class="stepup-account-skip">ما وصلتني الرسالة — إعادة الإرسال</button>',
          '<div id="stepupPasswordSetupStatus" class="stepup-account-footer-note">جاري إرسال رسالة اختيار كلمة المرور...</div>',
        '</div>',
      '</div>'
    ].join("");
  }

  function bindRecoveryUpgrade(){
    var recoverBtn = document.getElementById("stepupRecoverSessionBtn");
    var loginBtn = document.getElementById("stepupGoEmailLoginBtn");
    if(recoverBtn) recoverBtn.addEventListener("click",function(){ sendPasswordSetupEmail(findAnyPendingUpgrade(),true); });
    if(loginBtn) loginBtn.addEventListener("click",function(){
      var pending = findAnyPendingUpgrade();
      var email = pending && pending.newEmail ? pending.newEmail : "";
      showEmailLogin();
      setTimeout(function(){
        var emailEl = document.getElementById("stepupStudentEmail");
        if(emailEl) emailEl.value = email;
      },0);
    });
  }

  async function showRecoveryStep(pending){
    // Verified email: complete on-device with the student's existing PIN.
    activeVerifiedUpgrade=pending;
    replaceUpgradeOverlay(passwordHTML({},pending));
    bindPasswordUpgrade();
  }

  async function sendPasswordSetupEmail(pending,force){
    if(!pending || !pending.newEmail) return;
    var key = passwordSetupKey(pending);
    var last = Number(localStorage.getItem(key) || "0");
    var now = Date.now();
    if(!force && last && (now-last) < 120000){
      var existing = document.getElementById("stepupPasswordSetupStatus");
      if(existing) existing.textContent = "طُلب رابط الاستعادة مؤخرًا. تحققي من بريدك أو استخدمي PIN القديم.";
      return;
    }

    var btn = document.getElementById("stepupRecoverSessionBtn");
    var status = document.getElementById("stepupPasswordSetupStatus");
    if(btn){
      btn.disabled = true;
      btn.textContent = "جاري الإرسال...";
    }
    if(status) status.textContent = "جاري طلب رابط استعادة كلمة المرور...";

    try{
      auth().languageCode = "ar";
      await auth().sendPasswordResetEmail(pending.newEmail);
      localStorage.setItem(key,String(now));
      if(status) status.textContent = "طُلب رابط الاستعادة. تحققي من البريد والرسائل غير المرغوبة؛ وصوله قد يتأخر.";
      if(force) alert("تم طلب رابط استعادة كلمة المرور. تحققي من البريد والرسائل غير المرغوبة؛ وصوله قد يتأخر.");
    }catch(error){
      console.error("StepUp password setup email failed",error);
      if(status) status.textContent = "تعذر طلب الاستعادة. يمكنك استخدام PIN القديم مباشرة.";
      if(force) alert("تعذر إعادة الإرسال: " + friendlyError(error,"reset"));
    }finally{
      if(btn && document.body.contains(btn)){
        btn.disabled = false;
        btn.textContent = "نسيت PIN القديم — استعادة كلمة المرور بالبريد";
      }
    }
  }

  async function recoverVerifiedSession(){
    return sendPasswordSetupEmail(findAnyPendingUpgrade(),true);
  }

  function passwordHTML(profile,pending){
    var firstName = esc(((profile && profile.displayName) || "طالبة").trim().split(/\s+/)[0]);
    return [
      '<div id="stepupAccountUpgradeOverlay" class="stepup-account-overlay" dir="rtl" role="dialog" aria-modal="true">',
        '<div class="stepup-account-upgrade-card">',
          '<div class="stepup-account-update-badge">2 من 2</div>',
          '<h2>تم التحقق من البريد ✓</h2>',
          '<p class="stepup-account-lead">اختاري كلمة المرور هنا مباشرة، دون انتظار رسالة ثانية. سيبقى حسابك وتقدمك محفوظين.</p>',
          '<div class="stepup-account-email-chip">' + esc(pending.newEmail) + '</div>',
          '<div class="stepup-account-form">',
            '<label for="stepupUpgradePassword">كلمة المرور الجديدة</label>',
            '<input id="stepupUpgradePassword" type="password" autocomplete="new-password" placeholder="8 أحرف أو أكثر">',
            '<label for="stepupUpgradePasswordConfirm">تأكيد كلمة المرور</label>',
            '<input id="stepupUpgradePasswordConfirm" type="password" autocomplete="new-password" placeholder="أعيدي كتابة كلمة المرور">',
            '<label for="stepupUpgradePin">PIN القديم للتأكيد الأخير</label>',
            '<input id="stepupUpgradePin" type="password" inputmode="numeric" maxlength="4" autocomplete="current-password" placeholder="4 أرقام">',
          '</div>',
          '<button id="stepupFinishUpgradeBtn" class="btn btn-primary stepup-account-main-btn">حفظ كلمة المرور ومتابعة STEP UP</button>',
          '<button id="stepupSkipVerifiedUpgradeBtn" class="stepup-account-skip" type="button">المتابعة الآن دون إكمال كلمة المرور</button>',
          '<button id="stepupRecoverSessionBtn" class="stepup-account-skip" type="button">نسيت PIN القديم — استعادة كلمة المرور بالبريد</button>',
          '<div id="stepupPasswordSetupStatus" class="stepup-account-footer-note" aria-live="polite"></div>',
          '<div class="stepup-account-footer-note">بعد هذه الخطوة يمكنك الدخول بالبريد وكلمة المرور الجديدة واستعادة كلمة المرور عند الحاجة.</div>',
        '</div>',
      '</div>'
    ].join("");
  }

  async function getStudentProfileForUpgrade(user){
    var snap = await db().collection("users").doc(user.uid).get();
    if(!snap.exists) return null;
    var profile = snap.data() || {};
    return profile.role === "student" ? profile : null;
  }

  function replaceUpgradeOverlay(html){
    var old = document.getElementById("stepupAccountUpgradeOverlay");
    if(old) old.remove();
    document.body.insertAdjacentHTML("beforeend",html);
  }

  function bindInitialUpgrade(){
    var saveBtn = document.getElementById("stepupCompleteUpgradeBtn");
    var skipBtn = document.getElementById("stepupSkipUpgradeBtn");
    if(saveBtn) saveBtn.addEventListener("click",requestEmailUpgrade);
    if(skipBtn) skipBtn.addEventListener("click",skipUpgrade);
  }

  function bindVerificationUpgrade(){
    var checkBtn = document.getElementById("stepupCheckVerificationBtn");
    var resendBtn = document.getElementById("stepupResendVerificationBtn");
    var restartBtn = document.getElementById("stepupRestartUpgradeBtn");
    if(checkBtn) checkBtn.addEventListener("click",checkVerifiedEmail);
    if(resendBtn) resendBtn.addEventListener("click",resendVerificationEmail);
    if(restartBtn) restartBtn.addEventListener("click",restartEmailUpgrade);
  }

  function bindPasswordUpgrade(){
    var finishBtn=document.getElementById("stepupFinishUpgradeBtn");
    var skipBtn=document.getElementById("stepupSkipVerifiedUpgradeBtn");
    var recoverBtn=document.getElementById("stepupRecoverSessionBtn");
    if(finishBtn)finishBtn.addEventListener("click",finishPasswordUpgrade);
    if(skipBtn)skipBtn.addEventListener("click",continueWithoutPassword);
    if(recoverBtn)recoverBtn.addEventListener("click",function(){sendPasswordSetupEmail(activeVerifiedUpgrade||findAnyPendingUpgrade(),true);});
  }
  function continueWithoutPassword(){
    var pending=activeVerifiedUpgrade||findAnyPendingUpgrade();
    if(pending)sessionStorage.setItem(skipKey(pending.uid),"1");
    document.getElementById("stepupAccountUpgradeOverlay")?.remove();
    if(!auth().currentUser)window.location.reload();
  }

  async function maybeShowUpgrade(){
    if(upgradeBusy) return;
    if(document.getElementById("stepupAccountUpgradeOverlay")) return;
    if(!firebase.apps || !firebase.apps.length) return;

    var user = auth().currentUser;
    if(!user){
      var signedOutPending=findAnyPendingUpgrade();
      if(signedOutPending&&signedOutPending.startedAt&&(Date.now()-Date.parse(signedOutPending.startedAt))>86400000){
        clearPendingUpgrade(signedOutPending);
        signedOutPending=null;
      }
      if(signedOutPending&&sessionStorage.getItem(skipKey(signedOutPending.uid))!=="1"){
        await showRecoveryStep(signedOutPending);
      }
      return;
    }

    try{
      var pending = readPendingByUid(user.uid);
      if(pending){
        if(sessionStorage.getItem(skipKey(pending.uid))==="1")return;
        try{
          await user.reload();
        }catch(e){
          if(e && e.code === "auth/user-token-expired"){
            await showRecoveryStep(pending);
            return;
          }
        }
        user = auth().currentUser || user;
        var pendingProfile = null;
        try{
          pendingProfile = await getStudentProfileForUpgrade(user);
        }catch(profileError){
          if(profileError && profileError.code === "auth/user-token-expired"){
            await showRecoveryStep(pending);
            return;
          }
          throw profileError;
        }
        if(!pendingProfile) return;

        if(String(user.email || "").toLowerCase() === String(pending.newEmail || "").toLowerCase()){
          await showRecoveryStep(pending);
        }else{
          // Email linking is retired: an unconfirmed request is simply dropped.
          clearPendingUpgrade(pending);
        }
        return;
      }
      // Email linking is retired: students keep signing in with name + PIN.
    }catch(error){
      console.warn("StepUp account upgrade prompt unavailable",error);
    }
  }

  async function requestEmailUpgrade(){
    if(upgradeBusy) return;

    var email = ((document.getElementById("stepupUpgradeEmail") || {}).value || "").trim().toLowerCase();
    var emailConfirm = ((document.getElementById("stepupUpgradeEmailConfirm") || {}).value || "").trim().toLowerCase();
    var pin = ((document.getElementById("stepupUpgradePin") || {}).value || "").trim();

    if(!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){
      alert("اكتبي بريدًا إلكترونيًا صحيحًا.");
      return;
    }
    if(email !== emailConfirm){
      alert("البريد الإلكتروني وتأكيد البريد غير متطابقين.");
      return;
    }
    if(isLegacyEmail(email)){
      alert("استخدمي بريدك الإلكتروني الحقيقي.");
      return;
    }
    if(!/^\d{4}$/.test(pin)){
      alert("أدخلي PIN الحالي المكوّن من 4 أرقام.");
      return;
    }

    var user = auth().currentUser;
    if(!user || !isLegacyEmail(user.email)){
      alert("تعذر بدء التحديث من هذا الحساب. أعيدي تسجيل الدخول بالاسم وPIN.");
      return;
    }

    var legacyEmail = String(user.email).toLowerCase();
    var oldPassword = legacyPasswordFromCurrentEmail(legacyEmail,pin);
    var btn = document.getElementById("stepupCompleteUpgradeBtn");

    upgradeBusy = true;
    if(btn){
      btn.disabled = true;
      btn.textContent = "جاري إرسال رسالة التحقق...";
    }

    try{
      var credential = firebase.auth.EmailAuthProvider.credential(legacyEmail,oldPassword);
      await user.reauthenticateWithCredential(credential);

      if(typeof user.verifyBeforeUpdateEmail !== "function"){
        throw new Error("Firebase verifyBeforeUpdateEmail is not available.");
      }

      auth().languageCode = "ar";
      await user.verifyBeforeUpdateEmail(email);

      var pending = {
        uid:user.uid,
        legacyEmail:legacyEmail,
        newEmail:email,
        startedAt:new Date().toISOString()
      };
      savePendingUpgrade(pending);
      sessionStorage.removeItem(skipKey(user.uid));

      var profile = await getStudentProfileForUpgrade(user);
      replaceUpgradeOverlay(verificationHTML(profile || {},pending));
      bindVerificationUpgrade();
    }catch(error){
      console.error("StepUp email verification request failed",error);
      alert("لم يتم تغيير حسابك. " + friendlyError(error,"upgrade"));
    }finally{
      upgradeBusy = false;
      if(btn && document.body.contains(btn)){
        btn.disabled = false;
        btn.textContent = "إرسال رسالة التحقق";
      }
    }
  }

  async function resendVerificationEmail(){
    if(upgradeBusy) return;
    var user = auth().currentUser;
    if(!user) return alert("أعيدي تسجيل الدخول ثم حاولي مرة أخرى.");

    var pending = readPendingByUid(user.uid);
    if(!pending || !pending.newEmail) return alert("لم نجد طلب تحقق قيد الانتظار.");

    var btn = document.getElementById("stepupResendVerificationBtn");
    upgradeBusy = true;
    if(btn){
      btn.disabled = true;
      btn.textContent = "جاري إعادة الإرسال...";
    }

    try{
      auth().languageCode = "ar";
      await user.verifyBeforeUpdateEmail(pending.newEmail);
      alert(
        "أُعيد إرسال رسالة التحقق ✓\n\n" +
        "تحققي من Inbox ثم Junk / Spam.\n" +
        "ابحثي عن المرسل: noreply@step-c44ef.firebaseapp.com"
      );
    }catch(error){
      if(error && error.code === "auth/requires-recent-login"){
        alert("انتهت صلاحية جلسة التحقق. ارجعي إلى الدخول بالاسم وPIN ثم حاولي إعادة الإرسال مرة أخرى.");
      }else{
        alert("تعذر إعادة الإرسال: " + friendlyError(error,"upgrade"));
      }
    }finally{
      upgradeBusy = false;
      if(btn && document.body.contains(btn)){
        btn.disabled = false;
        btn.textContent = "إعادة إرسال رسالة التحقق";
      }
    }
  }

  async function checkVerifiedEmail(){
    if(upgradeBusy) return;
    var user = auth().currentUser;
    if(!user){
      var signedOutPending = findAnyPendingUpgrade();
      if(signedOutPending){
        await showRecoveryStep(signedOutPending);
        return;
      }
      return alert("لم نجد جلسة التحديث. أعيدي الدخول بالاسم وPIN.");
    }

    var pending = readPendingByUid(user.uid) || findAnyPendingUpgrade();
    if(!pending) return alert("لم نجد طلب تحديث قيد الانتظار.");

    var btn = document.getElementById("stepupCheckVerificationBtn");
    upgradeBusy = true;
    if(btn){
      btn.disabled = true;
      btn.textContent = "جاري التحقق...";
    }

    try{
      await user.reload();
      user = auth().currentUser || user;
      if(String(user.email || "").toLowerCase() !== String(pending.newEmail || "").toLowerCase()){
        alert("لم يكتمل التحقق بعد. افتحي رسالة Firebase في بريدك واضغطي رابط التحقق، ثم ارجعي وحاولي مرة أخرى.");
        return;
      }

      await showRecoveryStep(pending);
    }catch(error){
      if(error && error.code === "auth/user-token-expired"){
        await showRecoveryStep(pending);
      }else{
        alert("تعذر التأكد من حالة البريد: " + friendlyError(error,"upgrade"));
      }
    }finally{
      upgradeBusy = false;
      if(btn && document.body.contains(btn)){
        btn.disabled = false;
        btn.textContent = "تم التحقق من البريد";
      }
    }
  }

  async function restartEmailUpgrade(){
    var user = auth().currentUser;
    if(!user) return;
    var pending = readPendingByUid(user.uid);
    if(!pending) return;

    try{ await user.reload(); }catch(e){}
    user = auth().currentUser || user;

    if(String(user.email || "").toLowerCase() === String(pending.newEmail || "").toLowerCase()){
      alert("تم التحقق من البريد بالفعل. أكملي الآن اختيار كلمة المرور.");
      var profileDone = await getStudentProfileForUpgrade(user);
      activeVerifiedUpgrade=pending;
      replaceUpgradeOverlay(passwordHTML(profileDone || {},pending));
      bindPasswordUpgrade();
      return;
    }

    clearPendingUpgrade(pending);
    var profile = await getStudentProfileForUpgrade(user);
    replaceUpgradeOverlay(upgradeHTML(profile || {}));
    bindInitialUpgrade();
  }

  async function finishPasswordUpgrade(){
    if(upgradeBusy)return;
    var password=((document.getElementById("stepupUpgradePassword")||{}).value||"");
    var confirmation=((document.getElementById("stepupUpgradePasswordConfirm")||{}).value||"");
    var pin=((document.getElementById("stepupUpgradePin")||{}).value||"").trim();
    if(password.length<8)return alert("اختاري كلمة مرور من 8 أحرف أو أكثر.");
    if(password!==confirmation)return alert("كلمة المرور وتأكيدها غير متطابقين.");
    if(!/^\d{4}$/.test(pin))return alert("أدخلي PIN القديم المكوّن من 4 أرقام.");

    var pending=activeVerifiedUpgrade||(auth().currentUser?readPendingByUid(auth().currentUser.uid):null)||findAnyPendingUpgrade();
    if(!pending?.uid||!pending?.legacyEmail||!pending?.newEmail){
      alert("لم نجد طلب ربط البريد. ارجعي للدخول بحسابك الحالي، ولا تنشئي حسابًا جديدًا.");
      return;
    }
    var btn=document.getElementById("stepupFinishUpgradeBtn");
    var status=document.getElementById("stepupPasswordSetupStatus");
    upgradeBusy=true;
    if(btn){btn.disabled=true;btn.textContent="جاري حفظ كلمة المرور...";}
    if(status)status.textContent="نتأكد من حسابك الأصلي ونحفظ كلمة المرور...";
    try{
      // Firebase keeps the original password when a verified email address changes.
      // Signing into the verified address with the original PIN-derived password
      // also restores an expired session without creating another user or UID.
      var oldPassword=legacyPasswordFromCurrentEmail(pending.legacyEmail,pin);
      var result=await auth().signInWithEmailAndPassword(pending.newEmail,oldPassword);
      var user=result.user;
      if(user.uid!==pending.uid){
        await auth().signOut();
        throw new Error("الحساب لا يطابق حساب الطالبة الأصلي. لم تُغيّر كلمة المرور.");
      }
      await user.reload();
      if(String(user.email||"").toLowerCase()!==String(pending.newEmail).toLowerCase()){
        throw new Error("يجب تأكيد البريد الجديد أولًا بالضغط على رابط رسالة التحقق الأولى.");
      }
      await user.updatePassword(password);
      localStorage.setItem(upgradedKey(pending.legacyEmail),"1");
      sessionStorage.removeItem(skipKey(pending.uid));
      clearPendingUpgrade(pending);
      document.getElementById("stepupAccountUpgradeOverlay")?.remove();
      alert("تم إعداد كلمة المرور بنجاح ✓\n\nحسابك نفسه وجميع نتائجك وشهاداتك محفوظة.\nاستخدمي البريد وكلمة المرور الجديدة للدخول لاحقًا.");
    }catch(error){
      console.error("StepUp direct password setup failed",error?.code||error?.message||error);
      var code=error?.code||"";
      var message=["auth/wrong-password","auth/invalid-credential","auth/invalid-login-credentials"].includes(code)?
        "PIN القديم غير صحيح، أو سبق تعيين كلمة مرور. تحققي من PIN أو استخدمي استعادة كلمة المرور بالبريد.":
        ["auth/user-not-found","auth/invalid-email"].includes(code)?
        (clearPendingUpgrade(pending),"لم يكتمل ربط البريد، ولا حاجة له بعد الآن. ادخلي باسمك ورمز PIN كالمعتاد."):
        friendlyError(error,"upgrade");
      if(status)status.textContent="لم نتمكن من الحفظ: "+message;
      else alert("لم يتغير حسابك: "+message);
    }finally{
      upgradeBusy=false;
      if(btn&&document.body.contains(btn)){btn.disabled=false;btn.textContent="حفظ كلمة المرور ومتابعة STEP UP";}
    }
  }

  function enhanceAuthUI(){
    var nameEl = document.getElementById("stName");
    var pinEl = document.getElementById("stPin");
    if(!nameEl || !pinEl) return;

    var root = nameEl.closest(".student-entry-card") || document.getElementById("authBox");
    if(!root || root.querySelector(".stepup-account-actions")) return;

    var note = root.querySelector(".quick-entry-note");
    if(note){
      note.setAttribute("dir","rtl");
      note.innerHTML =
        '<strong>اكتبي اسمك ورمز PIN ثم اضغطي «دخول بالحساب الحالي».</strong><br>' +
        '• أول مرة لك؟ اختاري «إنشاء حساب جديد — أول مرة فقط».<br>' +
        '• نسيتِ رمز PIN؟ تواصلي مع معلمتك.';
    }

    var primary = root.querySelector("button.btn-primary");
    if(primary && /studentContinue/.test(primary.getAttribute("onclick") || "")){
      primary.textContent = "دخول بالحساب الحالي";
    }

    var forcedClassCode = classCodeFromUrl();
    var actions = document.createElement("div");
    actions.className = "stepup-account-actions";

    var createBtn = document.createElement("button");
    createBtn.type = "button";
    createBtn.className = "btn btn-secondary stepup-account-create";
    createBtn.textContent = "إنشاء حساب جديد — أول مرة فقط";
    createBtn.addEventListener("click",function(){ studentRegister(forcedClassCode); });

    var emailBtn = document.createElement("button");
    emailBtn.type = "button";
    emailBtn.className = "stepup-account-email-entry";
    emailBtn.textContent = "ربطتِ بريدك سابقًا واخترتِ كلمة مرور؟ الدخول بالبريد";
    emailBtn.addEventListener("click",showEmailLogin);

    actions.appendChild(createBtn);
    actions.appendChild(emailBtn);

    if(primary && primary.parentNode){
      primary.insertAdjacentElement("afterend",actions);
    }else{
      root.appendChild(actions);
    }
  }

  // ---- Login button feedback + PIN capture -------------------------------
  // The live sign-in function is provided by student-flow-guard.js, which
  // reloads the page after a successful sign-in. We wrap it to (1) show at
  // once that the tap was received, (2) remember the PIN for this tab so it is
  // saved to the student's profile after the reload, and (3) sign in students
  // who started linking an email on this device instead of creating a new,
  // empty account for them.
  var PIN_SAVE_KEY = "stepup_pin_to_save";

  function loginButtons(){
    var root = document.getElementById("stName");
    root = root ? (root.closest(".student-entry-card") || document.getElementById("authBox") || document) : document;
    return Array.prototype.slice.call(root.querySelectorAll("button.btn-primary, .stepup-account-create, .stepup-account-email-entry"));
  }

  function setLoginBusy(on){
    loginButtons().forEach(function(b){
      if(on){
        if(!b.dataset.idleText) b.dataset.idleText = b.textContent;
        b.disabled = true;
        if(b.classList.contains("btn-primary")) b.textContent = "جاري الدخول… ⏳";
      }else{
        b.disabled = false;
        if(b.dataset.idleText){ b.textContent = b.dataset.idleText; delete b.dataset.idleText; }
      }
    });
  }

  function rememberPin(){
    var pinEl = document.getElementById("stPin");
    var pin = pinEl ? pinEl.value.trim() : "";
    try{ if(/^\d{4}$/.test(pin)) sessionStorage.setItem(PIN_SAVE_KEY,pin); }catch(e){}
  }

  async function tryPendingLogin(forcedClassCode){
    var nameEl = document.getElementById("stName");
    var codeEl = document.getElementById("stClassCode");
    var pinEl = document.getElementById("stPin");
    var name = nameEl ? nameEl.value.trim() : "";
    var classCode = String(forcedClassCode || (codeEl ? codeEl.value : "") || "").trim().toUpperCase();
    var pin = pinEl ? pinEl.value.trim() : "";
    if(!name || !classCode || !/^\d{4}$/.test(pin)) return false;
    var creds = await legacyCreds(name,classCode,pin);
    var pending = readPendingByLegacy(creds.email);
    if(!pending || !pending.newEmail) return false;
    try{
      await auth().signInWithEmailAndPassword(creds.email,creds.password);
      return true; // email was never confirmed: the original login still works
    }catch(e){}
    try{
      await auth().signInWithEmailAndPassword(pending.newEmail,creds.password);
      return true;
    }catch(e){
      console.warn("StepUp pending-email login failed",e && e.code);
      return false;
    }
  }

  function wrapLiveLogin(){
    var live = window.PROVE && window.PROVE.studentContinue;
    if(!live || live.__busyWrapped) return;
    // Wait until the flow guard has installed its version, then wrap that one.
    if(!live.__accountGuardPatched && live !== studentContinue) return;
    if(!live.__accountGuardPatched && (Date.now() - startedAt) < 3000) return;
    var wrapped = async function(forcedClassCode){
      if(wrapped.__running) return;
      wrapped.__running = true;
      rememberPin();
      setLoginBusy(true);
      try{
        if(await tryPendingLogin(forcedClassCode)){ window.location.reload(); return; }
        return await live.apply(this,arguments);
      }finally{
        wrapped.__running = false;
        setTimeout(function(){ setLoginBusy(false); },400);
      }
    };
    wrapped.__busyWrapped = true;
    if(live.__accountGuardPatched) wrapped.__accountGuardPatched = live.__accountGuardPatched;
    window.PROVE.studentContinue = wrapped;
  }
  var startedAt = Date.now();

  function savePinAfterLogin(user){
    if(!user) return;
    var pin = null;
    try{ pin = sessionStorage.getItem(PIN_SAVE_KEY); }catch(e){}
    if(!pin) return;
    Promise.resolve(savePin(user.uid,pin)).then(function(done){
      if(done){ try{ sessionStorage.removeItem(PIN_SAVE_KEY); }catch(e){} }
    });
  }

  function scheduleEnhance(){
    clearTimeout(observerTimer);
    observerTimer = setTimeout(function(){
      enhanceAuthUI();
      wrapLiveLogin();
      maybeShowUpgrade();
    },80);
  }

  window.PROVE.studentContinue = studentContinue;
  window.PROVE.studentRegister = studentRegister;

  window.STEPUP_ACCOUNT = {
    showEmailLogin:showEmailLogin,
    studentEmailLogin:studentEmailLogin,
    studentResetPassword:studentResetPassword,
    maybeShowUpgrade:maybeShowUpgrade,
    requestEmailUpgrade:requestEmailUpgrade,
    checkVerifiedEmail:checkVerifiedEmail,
    recoverVerifiedSession:recoverVerifiedSession,
    resendVerificationEmail:resendVerificationEmail,
    finishPasswordUpgrade:finishPasswordUpgrade,
    skipUpgrade:skipUpgrade,
    isLegacyEmail:isLegacyEmail
  };

  try{
    auth().onAuthStateChanged(function(user){
      savePinAfterLogin(user);
      setTimeout(maybeShowUpgrade,220);
    });
  }catch(error){
    console.warn("StepUp account auth observer unavailable",error);
  }

  var observer = new MutationObserver(scheduleEnhance);
  observer.observe(document.documentElement,{childList:true,subtree:true});
  window.addEventListener("DOMContentLoaded",scheduleEnhance);
  setTimeout(scheduleEnhance,120);
  setTimeout(scheduleEnhance,1000);
  setTimeout(scheduleEnhance,3200);
})();